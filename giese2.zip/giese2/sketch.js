function setup() {
  createCanvas(400, 400);
 background(0);
  colorMode(RGB);
  angleMode(DEGREES);
  F=0;
  rx=0;
  ry=0;
}

function draw() {
  man(100,100);
  man(200,200);
  if(F===0)
    {
      for (let i = 0; i < 9; i++)
    {
      rx = random(400);
      ry = random(400);
      man(rx, ry);
    }
      F=1;
    }
  
}

function man(x,y)
{
  push();
  scale(x/y);
  rotate(PI*rx);
translate(x, y);
  rect(0, -50, 50,50);
  fill(0);
  rect(20, -30, 4,8);
  rect(40, -30, 4,8);
  fill(51);
  rect(3,0,45,70);
  rect(60,20,15,15);
  rect(-30,20,15,15);
  rect(30,75,30,20);
  rect(5,75,30,20);
  
  pop();
}