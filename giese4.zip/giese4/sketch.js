var img;
var img2;
var png;
function preload() {
  img = loadImage("forest.jpg");
  img2 = loadImage("face.jpg");
  png = loadImage("glass.png");
}

function setup () {

  createCanvas(2000, 2000);
 textSize(50);
    textAlign(CENTER, CENTER);
    textFont('Comic Neue');
}

function draw () {
  image(png, mouseY, mouseX) ;
  image(img, 0, 0);
  image(img2, mouseX, mouseY);
  text('programming is cool', 1000, 1500);
}