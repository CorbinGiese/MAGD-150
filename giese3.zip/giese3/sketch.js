var spirit = [];
function setup() {
  createCanvas(400, 400);
  colorMode(RGB)
  background(50,0,50);
  fill(150,60,0);
  ellipse(200,200,300,300);
  fill(0);
  rect(100,120,70,50);
  rect(230,120,50,60);
  rect(100, 230, 200, 50);
  fill(0,50,0)
  rect(180, 20, 30, 50)
  fill(150,60,0);
  noStroke();
  rect(120, 229, 30, 30);
  rect(250, 251, 30, 30);
  fill(255)
  for (var i = 0; i < 5; i++) {
		var x=random(width);
		var y=random(height);
		var r=i * 5;
		spirit[i] = new Ghost(x, y, r);
}}

function draw() {
  stroke(0)
	for (var i = 0; i < spirit.length; i++) {
		spirit[i].display();
        spirit[i].move();
}}
  
  function Ghost(tempX, tempY, tempDiameter) {

	this.x=tempX;
	this.y=tempY;
	this.diameter=tempDiameter;
    this.display = function () {
		ellipse(this.x, this.y, this.diameter, this.diameter);
	};
    this.move = function () {
         if(this.x<=mouseX)
           {
             this.x++
             if(this.y<=mouseY)
               {
                 this.y++
               }
           }
      else if(this.x>=mouseX)
           {
             this.x--
             if(this.y>=mouseY)
               {
                 this.y--
               }
           }
    };
  }
