var capture;
var woohoo;
var mic;
function preload(){
    woohoo = loadSound('woohoo.mp3');
}
function setup() {

  createCanvas(1000, 1000);
 capture = createCapture();
  capture.hide();
  mic = new p5.AudioIn();
  mic.start();
  strokeWeight(3);

}
function mousePressed(){
  woohoo.play();
}

function draw() {
  mic.start();
  micLevel = mic.getLevel();
  var aspectRatio = capture.height/capture.width;
  image(capture, 0, 0, 300, 300);
  filter(POSTERIZE, 3);
  for(let i=0; i<10; i++)
  {
    micLevel = mic.getLevel();
    ellipse(500,500,(micLevel*10)*10,(micLevel*10)*10); 
    //for whatever reason this takes a minute to get going, i don't know how to fix it
  } 
}